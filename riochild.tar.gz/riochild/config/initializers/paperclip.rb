require "paperclip" 
Paperclip.options[:command_path] = '/usr/bin/'
Paperclip.options[:swallow_stderr] = false
