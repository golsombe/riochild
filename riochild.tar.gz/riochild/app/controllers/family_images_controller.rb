class FamilyImagesController < ApplicationController
active_scaffold :family_image do |config|
	end
end
