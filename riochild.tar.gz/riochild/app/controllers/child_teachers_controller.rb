class ChildTeachersController < ApplicationController
 active_scaffold :ChildTeachers do |config|
  end
end
