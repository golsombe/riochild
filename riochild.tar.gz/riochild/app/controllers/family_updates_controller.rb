class FamilyUpdatesController < ApplicationController
active_scaffold :family_update do |config|
	end
end
