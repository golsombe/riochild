class FamiliesController < ApplicationController
active_scaffold :family do |config|
	end
end
