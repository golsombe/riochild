class FamilyChildrenController < ApplicationController
	active_scaffold :family_child do |config|
	end
end
