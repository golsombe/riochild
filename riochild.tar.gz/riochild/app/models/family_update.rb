class FamilyUpdate < ActiveRecord::Base
	belongs_to :family
end
