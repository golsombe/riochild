class ChildUpdate < ActiveRecord::Base
	belongs_to :child
end
