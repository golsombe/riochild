require 'test_helper'

class ChildUpdatesHelperTest < ActionView::TestCase
end
