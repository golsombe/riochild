require 'test_helper'

class FamilyChildrenHelperTest < ActionView::TestCase
end
