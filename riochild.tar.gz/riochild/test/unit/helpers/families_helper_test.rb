require 'test_helper'

class FamiliesHelperTest < ActionView::TestCase
end
