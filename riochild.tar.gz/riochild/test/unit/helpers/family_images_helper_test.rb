require 'test_helper'

class FamilyImagesHelperTest < ActionView::TestCase
end
