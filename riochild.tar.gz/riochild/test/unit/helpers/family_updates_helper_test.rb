require 'test_helper'

class FamilyUpdatesHelperTest < ActionView::TestCase
end
