require 'test_helper'

class ChildImagesHelperTest < ActionView::TestCase
end
